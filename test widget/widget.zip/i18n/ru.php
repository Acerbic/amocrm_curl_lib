<?php
$messages=array (
  'widget.name' => 'Обработка контакта',
  'widget.short_description' => 'Обработка обновлённого контакта.',
  'widget.description' => 'Для всех контактов сохранённых с признаком `Не рассмотрено` назначается ответсвенный менеджер, создаются сделка и задача.',
  'settings.phpendpoint' => 'PHP endpoint',
);